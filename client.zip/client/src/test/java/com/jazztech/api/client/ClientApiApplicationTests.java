package com.jazztech.api.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
